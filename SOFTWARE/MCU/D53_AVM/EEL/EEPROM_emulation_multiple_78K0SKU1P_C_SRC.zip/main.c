/****************************************************************
		78K0S/KU1+ EEPROM Emulation sample main program
****************************************************************/

#include "init_setting.h"

#define TRUE	0x01;
#define FALSE	0x00;

/***************************************
	Function declaration
 ***************************************/
// Assembler function
extern bit _eeprom_write(unsigned char *);	// Assembler function
extern bit _eeprom_read(unsigned char *);	// Reads to EEPROM

/***************************************
	Reads to EEPROM
 ***************************************/
typedef struct eeprom_data{
	unsigned char	uc_data_no;		// Data number
	unsigned char	uc_eeprom_data[2];	// Data
	unsigned char	uc_delimiter;		// Delimiter
} struct_eeprom_data;

/****************************************************************
		Main function
****************************************************************/
void  main(void)
{

	/*	Variable declaration	*/
	struct_eeprom_data	s_eeprom_data;
	unsigned char		uc_eeprom_func_result;

	/*	Initializes EEPROM data 0	*/
	s_eeprom_data.uc_data_no = 0;
	s_eeprom_data.uc_eeprom_data[0] = 0x01;
	s_eeprom_data.uc_eeprom_data[1] = 0x10;
	s_eeprom_data.uc_delimiter = 0;

	/*	Writes to EEPROM data 0		*/
	if(_eeprom_write(&(s_eeprom_data.uc_data_no)))
	{
		/*	Write failure	*/
		uc_eeprom_func_result = FALSE;
	}
	{
		/*	Write successful	*/
		uc_eeprom_func_result = TRUE;
	}

	/*	Initializes EEPROM data 1	*/
	s_eeprom_data.uc_data_no = 1;
	s_eeprom_data.uc_eeprom_data[0] = 0x80;
	s_eeprom_data.uc_eeprom_data[1] = 0x5A;
	s_eeprom_data.uc_delimiter = 0;

	/*	Initializes EEPROM data 1	*/
	if(_eeprom_write(&(s_eeprom_data.uc_data_no)))
	{
		/*	Write failure	*/
		uc_eeprom_func_result = FALSE;
	}
	{
		/*	Write successful	*/
		uc_eeprom_func_result = TRUE;
	}

	/*	Specifies reading of EEPROM data 0	*/
	s_eeprom_data.uc_data_no = 0;

	/*	Reads EEPROM data 0	*/
	if(_eeprom_read(&(s_eeprom_data.uc_data_no)))
	{
		/*	Read failure	*/
		uc_eeprom_func_result = FALSE;
	}
	{
		/*	Read successful		*/
		uc_eeprom_func_result = TRUE;
	}

	/*	Reads specified EEPROM data1	*/
	s_eeprom_data.uc_data_no = 1;

	/*	Reads EEPROM data 1		*/
	if(_eeprom_read(&(s_eeprom_data.uc_data_no)))
	{
		/*	Read failure	*/
		uc_eeprom_func_result = FALSE;
	}
	{
		/*	Read successful	*/
		uc_eeprom_func_result = TRUE;
	}

	while(1);
}

/****************************************************************
		 Initialize SFR
****************************************************************/
void hdwinit()
{
	/*	STOP WDT	*/
	WDTM = WDTM_DATA;

	/*	Clock		*/
	PCC  = PCC_DATA;
	PPCC = PPCC_DATA;

	/*	Port2		*/
	P2  = 0;
	PM2 = PM2_DATA;
	PMC2 = PMC2_DATA;

	/*	Port3		*/
	P3  = 0;
	PM3 = PM3_DATA;

	/*	Port4		*/
	P4  = 0;
	PM4 = PM4_DATA;

	/*	Interrupt	*/
	MK0 = MK0_DATA;		// MASK0
}

